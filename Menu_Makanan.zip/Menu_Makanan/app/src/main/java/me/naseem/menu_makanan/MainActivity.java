package me.naseem.menu_makanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.os.Bundle;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> FotoMakanan = new ArrayList<>();
    private ArrayList<String> NamaMakanan = new ArrayList<>();
    private ArrayList<String> InfoMakanan = new ArrayList<>();
    private ArrayList<String> HargaMakanan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(FotoMakanan, NamaMakanan, InfoMakanan, HargaMakanan,this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    private void getDataFromInternet(){
        NamaMakanan.add("Lumpia");
        FotoMakanan.add("https://s3.theasianparent.com/cdn-cgi/image/height=412/tap-assets-prod/wp-content/uploads/sites/24/2021/07/lumpia-semarang-lead.jpg");
        InfoMakanan.add("Lumpia semarang (atau loenpia semarang) (bahasa Jawa: ꦭꦸꦤ꧀ꦥꦶꦪꦃ, translit. Lunpiyah) adalah makanan semacam rollade yang berisi rebung, telur, dan daging ayam atau udang. ");
        HargaMakanan.add("Harga : Rp 20.000");

        NamaMakanan.add("Gudeg");
        FotoMakanan.add("https://icone-inc.org/wp-content/uploads/2019/03/77B87DF8-53A6-42C7-A2F8-9AA744702560.jpeg");
        InfoMakanan.add("Gudeg dibuat dari buah nangka yang tumbuh di banyak pulau di Kepulauan Melayu, khususnya di Jawa, dan merupakan tanaman pangan yang cukup penting. Sejumlah besar rempah-rempah dan bumbu tertentu digunakan dalam proses perebusan, rempah ini juga meningkatkan masa simpan gudeg.");
        HargaMakanan.add("Harga : Rp 20.000");

        NamaMakanan.add("Soto");
        FotoMakanan.add("https://th.bing.com/th/id/OIP.o2VXyivO_GnQwMCcpgK6pQHaFj?w=241&h=181&c=7&r=0&o=5&dpr=1.25&pid=1.7");
        InfoMakanan.add("Soto adalah makanan khas Indonesia yang terbuat dari kaldu daging dan sayuran. Daging yang paling sering digunakan adalah daging sapi dan ayam, tetapi juga babi dan kambing");
        HargaMakanan.add("Harga : Rp 13.000");

        NamaMakanan.add("kwietiau Goreng");
        FotoMakanan.add("https://www.befren.com/wp-content/uploads/2018/10/Resep-Mudah-Membuat-Kwetiau-Goreng-Nikmat-befren.com_.jpg");
        InfoMakanan.add("Kwetiau goreng adalah kwetiau yang digoreng yang merupakan masakan Tionghoa Indonesia,[1] itu adalah hidangan mie yang digoreng yang beraroma dan pedas yang umum dijumpai di Indonesia");
        HargaMakanan.add("Harga : Rp 13.000");
        
        NamaMakanan.add("Ayam Bakar");
        FotoMakanan.add("https://4.bp.blogspot.com/-ICsTm2-QHzo/V2qqP4237kI/AAAAAAAAJmA/bJFje_yxKDIv9eO3kk2kayMYYcDvQthWwCLcB/s1600/Cara%2BMembuat%2BAyam%2BBakar%2BBetutu%2BBali%2Bdan%2BResep.jpg");
        InfoMakanan.add("Ayam bakar adalah makanan paling lumrah dijumpai ketika berada di jalan,makanan yang berbahan dasar ayam yang dibakar dengan baluran kecap dan bumbu yang beraneka ragam.");
        HargaMakanan.add("Harga : Rp 22.000");

        prosesRecyclerViewAdapter();
    }
}