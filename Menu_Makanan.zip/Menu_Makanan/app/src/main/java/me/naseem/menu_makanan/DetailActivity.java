package me.naseem.menu_makanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    ImageView img_makanan;
    TextView txt_namaMakanan,txt_infoMakanan,txt_hargaMakanan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        img_makanan = findViewById(R.id.img_makanan);
        txt_namaMakanan = findViewById(R.id.txt_namaMakanan);
        txt_infoMakanan = findViewById(R.id.txt_infoMakanan);
        txt_hargaMakanan = findViewById(R.id.txt_hargaMakanan);

        getIncomingExtra();
    }
    private void getIncomingExtra(){
        if(getIntent().hasExtra("Profile-Makanan") && getIntent().hasExtra("Nama-Makanan") && getIntent().hasExtra("Deskripsi-Makanan") && getIntent().hasExtra("Harga-Makanan"))
        {
            String fotoMakanan = getIntent().getStringExtra("Profile-Makanan");
            String namaMakanan = getIntent().getStringExtra("Nama-Makanan");
            String infoMakanan = getIntent().getStringExtra("Deskripsi-Makanan");
            String hargaMakanan = getIntent().getStringExtra("Harga-Makanan");

            setDataActivity(fotoMakanan, namaMakanan, infoMakanan, hargaMakanan);
        }
    }
    private void setDataActivity(String FotoMakanan, String NamaMakanan, String InfoMakanan, String HargaMakanan){
        Glide.with(this).asBitmap().load(FotoMakanan).into(img_makanan);
        txt_namaMakanan.setText(NamaMakanan);
        txt_infoMakanan.setText(InfoMakanan);
        txt_hargaMakanan.setText(HargaMakanan);
    }
}