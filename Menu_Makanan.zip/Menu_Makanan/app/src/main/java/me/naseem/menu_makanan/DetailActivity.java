package me.naseem.menu_makanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    ImageView imageViewFotoMakanan;
    TextView textViewNamaMakanan, textViewInfoMakanan, textViewHargaMakanan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        imageViewFotoMakanan = findViewById(R.id.imageViewFotoMakanan);
        textViewNamaMakanan = findViewById(R.id.textViewNamaMakanan);
        textViewInfoMakanan = findViewById(R.id.textViewInfoMakanan);
        textViewHargaMakanan = findViewById(R.id.textViewHargaMakanan);

        getIncomingExtra();
    }
    private void getIncomingExtra(){
        if(getIntent().hasExtra("Profile-Makanan") && getIntent().hasExtra("Nama-Makanan") && getIntent().hasExtra("Deskripsi-Makanan") && getIntent().hasExtra("Harga-Makanan"))
        {
            String fotoMakanan = getIntent().getStringExtra("Profile-Makanan");
            String namaMakanan = getIntent().getStringExtra("Nama-Makanan");
            String infoMakanan = getIntent().getStringExtra("Deskripsi-Makanan");
            String hargaMakanan = getIntent().getStringExtra("Harga-Makanan");

            setDataActivity(fotoMakanan, namaMakanan, infoMakanan, hargaMakanan);
        }
    }
    private void setDataActivity(String FotoMakanan, String NamaMakanan, String InfoMakanan, String HargaMakanan){
        Glide.with(this).asBitmap().load(FotoMakanan).into(imageViewFotoMakanan);
        textViewNamaMakanan.setText(NamaMakanan);
        textViewInfoMakanan.setText(InfoMakanan);
        textViewHargaMakanan.setText(HargaMakanan);
    }
}